# English OBS translationNotes

## Overview

translationNotes for [Open Bible Stories](http://ufw.io/obs) provides translators with exegetical information for each story and frame of Open Bible Stories. By providing historical, cultural, and linguistic information, together with interlinked information pertaining to key terms and translation theory, translators are equipped to translate and check their translations with excellence.

translationNotes were developed by the [Door43 World Missions Community](https://door43.org).  The entire project is made available under a [Creative Commons Attribution-ShareAlike 4.0 International License](http://creativecommons.org/licenses/by-sa/4.0), see the [LICENSE](https://git.door43.org/Door43/en--obs-tq/src/master/LICENSE.md) file for more information.

Please use the [issue queue](https://git.door43.org/Door43/en-obs-tn/issues) to provide feedback or suggestions for improvement.

## Resources

tN for OBS is included in [tS](http://ufw.io/ts) and [tC](http://ufw.io/tc).


## Historical

If you would like to see the original translationNotes pages in DokuWiki, you may visit https://dw.door43.org/en/obs/notes/home.

# 1 Chronicles 11 General Notes

#### Structure and formatting

The story of David begins here and continues throughout the remainder of this book. 

#### Special concepts in this chapter

##### King David the military leader
David was made the king of all Israel and was the leader of their army. He conquered Jerusalem and strengthened its defenses. He had many brave men in his army that did great deeds. (See: [[rc://en/tw/dict/bible/kt/works]])

## Links:

* __[1 Chronicles 11:01 Notes](./01.md)__

__[<<](../10/intro.md) | [>>](../12/intro.md)__

# 1 Chronicles 08 General Notes

#### Structure and formatting

This chapter records the genealogy of Saul's family.

## Links:

* __[1 Chronicles 08:01 Notes](./01.md)__

__[<<](../07/intro.md) | [>>](../09/intro.md)__

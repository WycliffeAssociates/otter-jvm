# 1 Chronicles 05 General Notes

#### Structure and formatting

This chapter records the descendants of Jacob's sons who lived east of the Jordan River: Reuben, Gad and Manasseh.

## Links:

* __[1 Chronicles 05:01 Notes](./01.md)__

__[<<](../04/intro.md) | [>>](../06/intro.md)__
